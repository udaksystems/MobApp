var io   = require('socket.io').listen(8080);
var five = require('johnny-five');

var stepper

var led;
var board = new five.Board();

board.on("ready", function() {
  //led control code
    led = new five.Led.RGB([9, 10, 11]);


       stepper = new five.Stepper({
        type: five.Stepper.TYPE.FOUR_WIRE,
        stepsPerRev: 48,
        pins: [5, 3, 4, 2]
      });

    io.sockets.on("connection", function(socket) {
        console.log("New connection: " + socket.id);

        socket.on("changeColor", function(e) {
            led.color(e.color);
            console.log(e.color);

            if(e.color == '#FF0000') {
              led.off();
            }
            else {
              led.on();
            }
        });

        socket.on("moveRight", function(e) {
          stepper.rpm(150).cw().step(500, function() {
            console.log("done 25% mR");
          });
        });

        socket.on("moveLeft", function(e) {
          stepper.rpm(150).ccw().step(500, function() {
            console.log("done 25% mL");
          });
        });
    });





    //stepper engine code


    this.repl.inject({ led: led });
});
